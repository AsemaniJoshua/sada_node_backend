-- AlterTable
ALTER TABLE `User` ADD COLUMN `isFirstTimeLogin` BOOLEAN NOT NULL DEFAULT true;
